import supabase from "../config/supabaseClient"
import { useEffect, useState } from "react"

import KapeCard from "../Components/KapeCard"

const Home = () => {
  const [fetchError, setFetchError]= useState(null)
  const [Kape, setKape] = useState(null)
  const [orderBy, setOrderBy] = useState('product_id')

  const handleDelete = (id) => {
    setKape(prevKape => {
      return prevKape.filter(kk => kk.product_id !== id)
    })

  }

  useEffect(() => {
    const fetchKape = async () => {
      const { data, error } = await supabase
      .from('products')
      .select()
      .order(orderBy, {ascending: false})

      if (error) {
        setFetchError('Could not fetch the table')
        setKape(null)
        console.log(error)
      }

      if (data) {
        setKape(data)
        setFetchError(null)
      }
    }
    fetchKape()

  }, [orderBy])

  return (
    <div className="page home">
    {fetchError && (<p>{fetchError}</p>)}
    {Kape && (
      <div className="Kape">
        <div className="order-by">
          <p>Order By:</p>
          <button onClick={() => setOrderBy('product_id')}>Default</button>
          <button onClick={() => setOrderBy('name')}>Name</button>
          <button onClick={() => setOrderBy('price')}>Price</button>
          {orderBy}
        </div>
        <div className="Kape-grid">
          {Kape.map(Item => (
            <KapeCard 
            key={Item.product_id} 
            Item={Item} 
            onDelete={handleDelete}
            />
           ))}
        </div>
      </div>
    )}
    </div>
  )
}

export default Home