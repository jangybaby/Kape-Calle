import { useState } from "react"
import supabase from "../config/supabaseClient"
import { useNavigate } from "react-router-dom"

const Create = () => {
  const navigate = useNavigate()

  const [name, setName] = useState('')
  const [description, setDesc] = useState('')
  const [price, setPrice] = useState('')
  const [formError, setFormError] = useState(null)

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (!name || !description || !price) {
      setFormError('Please fill in all the fields correctly')
      return
    }

    const { data, error } = await supabase
      .from('products')
      .insert([{ name, description, price }])
      .select()


    if (error) {
      console.log(error)
      setFormError('Please fill in all the fields correctly')
    }

    if (data) {
      console.log(data)
      setFormError(null)
      navigate('/')
    }
  }


  return (
    <div className="page create">
      <form onSubmit={handleSubmit}>
        <label htmlFor="name">Product Name:</label>
        <input
          type="varchar"
          id="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />

        <label htmlFor="description">Product Description:</label>
        <input
          type="text"
          id="description"
          value={description}
          onChange={(e) => setDesc(e.target.value)}
        />

        <label htmlFor="price">Product Price:</label>
        <input
          type="int"
          id="price"
          value={price}
          onChange={(e) => setPrice(e.target.value)}
        />

      <button>Add Product</button>

      {formError && <p className="error">{formError}</p>}
      </form>
    </div>
  )
}

export default Create