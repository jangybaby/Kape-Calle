import { Link } from "react-router-dom"
import supabase from "../config/supabaseClient"

const KapeCard = ({ Item, onDelete }) => {
    const handleDelete = async() => {
        const { data, error } = await supabase
            .from('products')
            .delete()
            .eq('product_id', Item.product_id)
            .select()

        if (error) {
            console.log(error)
        }

        if (data) {
            console.log(data)
            onDelete(Item.product_id)
        }
    }

    return (
        <div className="Kape-Card">
            <h3>{Item.name}</h3>
            <p>{Item.description}</p>
            <p>{Item.price}</p>
            <div className="buttons">
                <Link to={'/' + Item.product_id}>
                    <i className="material-icons">edit</i>                    
                </Link>
                <i className="material-icons" onClick={handleDelete}>delete</i>
            </div>
        </div>


    )
}

export default KapeCard